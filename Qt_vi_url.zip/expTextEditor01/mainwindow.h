#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>

#include "ViEditView.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void onModeChanged();                           // 編集モード変更時処理

    void cmdLineCursorPositionChanged(int, int);    // コマンドライン入力欄カーソル位置変更時処理
    void cmdLineTextChanged(const QString &);       // コマンドライン入力欄テキスト変更時処理
    void cmdLineReturnPressed();                    // コマンドライン入力欄Enterキー押下時処理

protected:
    bool eventFilter(QObject *obj, QEvent *event);  // コマンドライン入力欄イベント発生時処理

private:
    Ui::MainWindow  *ui;
    ViEditView      *m_editor = new ViEditView();       // テキスト編集欄
    QLineEdit       *m_cmdLineEdit = new QLineEdit();   // コマンドライン入力欄

};
#endif // MAINWINDOW_H
