#include "mainwindow.h"
#include "ui_mainwindow.h"

// Constructor
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    // 初期化処理
    ui->setupUi(this);
    setCentralWidget(m_editor);                 // ViEditコントロールの位置セット
    //onModeChanged();                          // 編集モード確認
    statusBar()->addWidget(m_cmdLineEdit , 1);  // コマンドライン入力欄追加
    m_cmdLineEdit->installEventFilter(this);    //

    // 受信シグナル設定
    connect(m_editor, SIGNAL(editModeChanged_high()), this, SLOT(onModeChanged()));
    connect(m_cmdLineEdit, SIGNAL(returnPressed()), this, SLOT(cmdLineReturnPressed()));
    connect(m_cmdLineEdit, SIGNAL(cursorPositionChanged(int,int)), this, SLOT(cmdLineCursorPositionChanged(int, int)));
    connect(m_cmdLineEdit, SIGNAL(textChanged(QString)), this, SLOT(cmdLineTextChanged(const QString)));
    connect(m_cmdLineEdit, SIGNAL(returnPressed()), this, SLOT(cmdLineReturnPressed(const QString)));

    // メンバ初期化
    m_editor->m_viEngine->setEditMode_low(ViEngine::EditMode::CMD);
}

// Destructor
MainWindow::~MainWindow()
{
    delete ui;
}

// 編集モード変更シグナル受信時処理
void MainWindow::onModeChanged()
{
    QString text;
    switch(m_editor->m_viEngine->editMode()){
        case ViEngine::EditMode::CMD:
            text = "CMD";
            break;
        case ViEngine::EditMode::INSERT:
            text = "INSERT";
            break;
        case ViEngine::EditMode::CMDLINE:
            m_cmdLineEdit->setText(":");
            m_cmdLineEdit->show();
            m_cmdLineEdit->setFocus(Qt::OtherFocusReason);
            return;
            break;
        default:
            text = "UnKnown";
            break;
    }
    m_cmdLineEdit->hide();
    statusBar()->showMessage(text);
}

// コマンドライン入力欄カーソル位置変更時処理
void MainWindow::cmdLineCursorPositionChanged(int oldPosition, int newPosition)
{
    if(newPosition == 0){
        //
        m_cmdLineEdit->setCursorPosition(1);
    }
}

// コマンドライン入力欄テキスト変更時処理
void MainWindow::cmdLineTextChanged(const QString & text){
    // 行頭の「:」を削除されたらexモード終了
    if( text.isEmpty() || text[0] != ':' ){
        m_editor->m_viEngine->setEditMode_low(ViEngine::EditMode::CMD);
    }
}

// コマンドライン入力欄Enterキー押下時処理
void MainWindow::cmdLineReturnPressed()
{
    QString text = m_cmdLineEdit->text();
    if( !text.isEmpty() && text[0] == ':'){
        m_editor->m_viEngine->processExCommand(text.mid(1));
    }
}

// コマンドライン入力欄のイベントフィルタ
bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if(obj == m_cmdLineEdit &&
       event->type() == QEvent::KeyPress &&
       m_editor->m_viEngine->editMode() == ViEngine::EditMode::CMDLINE){
        //
        QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
        if(keyEvent->key() == Qt::Key_Escape){
            // コマンドライン入力モードをキャンセルする
            m_editor->m_viEngine->setEditMode_low(ViEngine::EditMode::CMD);
            return true;
        }
    }
    return false;
}
