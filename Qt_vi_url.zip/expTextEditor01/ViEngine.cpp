#include "ViEngine.h"

ViEngine::ViEngine(QObject *parent)
    : QObject{parent}
{
}

ViEngine::~ViEngine()
{
}

////////////////////////////
// Property Setter/Getter //
////////////////////////////
// 編集モードSetter
void ViEngine::setEditMode_low(EditMode value)
{
    if(m_EditMode != value){
        m_EditMode = value;                 // Change Mode
        emit editModeChanged_low(value);    // signal transmission
    }
}

// 編集モードGetter
ViEngine::EditMode ViEngine::editMode()
{
    return m_EditMode;
}


///////////////////
// Public Method //
///////////////////
// 編集欄キー押下時処理
bool ViEngine::processKeyPressEvent(QKeyEvent *event)
{
    switch(m_EditMode){
        case EditMode::CMD:
            return cmdModeKeyPressEvent(event);    // コマンドモード時キー押下処理
            break;
        case EditMode::INSERT:
            return insModeKeyPressEvent(event);    // 挿入モード時キー押下処理
            break;
        default:
            break;
    }
    return false;
}

////////////////////
// Private Method //
////////////////////

//  コマンドモード時キー押下処理
bool ViEngine::cmdModeKeyPressEvent(QKeyEvent *event)
{
    QString text = event->text();
    if(text.isEmpty()){return false;}
    ushort chara = text[0].unicode();

    // コマンドの繰り返し回数取得
    if(chara >= '0' && chara <= '9')
    {
        m_repCount = m_repCount * 10 + (chara - '0');
        return true;
    }
    m_repCount <= 0 ? m_repCount = 1 : m_repCount;

    // コマンド解析＋実行
    switch(chara){
        case 'i':   // 編集モード＝インサートモードに変更
            setEditMode_low(EditMode::INSERT);
            break;
        case 'h':   // カーソル移動(左)
            emit moveCursor(QTextCursor::Left);
            break;
        case ' ':
            break;
        case 'l':   // カーソル移動(右)
            emit moveCursor(QTextCursor::Right);
            break;
        case 'k':   // カーソル移動(右)
            emit moveCursor(QTextCursor::Up);
            break;
        case 'j':   // カーソル移動(下)
            emit moveCursor(QTextCursor::Down);
            break;
        case ':':   // 編集モード＝コマンドライン入力に変更
            setEditMode_low(EditMode::CMDLINE);
            break;
        default:    // 想定外＝無視
            break;
    }
    m_repCount = 0;
    return true;
}

//  挿入モード時キー押下処理
bool ViEngine::insModeKeyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape ){
        // When "ESC" is pressed → Command Input Mode
        setEditMode_low(EditMode::CMD);
        return true;
    }
    return false;
}

// コマンドライン入力コマンド処理解析
void ViEngine::processExCommand(const QString &text){
    setEditMode_low(EditMode::CMD);
}
