#include "ViEditView.h"

// Constructor
ViEditView::ViEditView(QWidget *parent)
    : QPlainTextEdit(parent)
{
    // シグナルセット
    connect(m_viEngine, SIGNAL(editModeChanged_low(ViEngine::EditMode)), this, SLOT(setEditMode_high(ViEngine::EditMode)));
    connect(m_viEngine, SIGNAL(moveCursor(QTextCursor::MoveOperation)), this, SLOT(moveCursor(QTextCursor::MoveOperation)));
}

// Destructor
ViEditView::~ViEditView()
{
}


////////////////////////////
// Property Setter/Getter //
////////////////////////////
// Edit Mode Setter
void ViEditView::setEditMode_high(ViEngine::EditMode value)
{
    // カーソル幅変更
    switch(value){
        case ViEngine::EditMode::CMD:
            setCursorWidth(7);
            break;
        case ViEngine::EditMode::INSERT:
            setCursorWidth(1);
            break;
        default:
            break;
    }

    // 編集モードセット
    if(m_EditMode != value){
        m_EditMode = value;             // Change Mode
        emit editModeChanged_high();    // signal transmission
    }
}

// Mode Getter
ViEngine::EditMode ViEditView::editMode()
{
    return m_EditMode;
}


////////////
// Events //
////////////

// キー押下時処理
void ViEditView::keyPressEvent(QKeyEvent *event)
{
    if(m_viEngine != 0 && m_viEngine->processKeyPressEvent(event))
    {
        return;
    }
    QPlainTextEdit::keyPressEvent(event);
}

///////////////////
// Public Method //
///////////////////
// カーソル移動処理
void ViEditView::moveCursor(QTextCursor::MoveOperation mv)
{
    QTextCursor cur = textCursor();
    cur.movePosition(mv, QTextCursor::MoveAnchor, m_viEngine->m_repCount);
    setTextCursor(cur);
}



////////////////////
// Private Method //
////////////////////
