#ifndef VIENGINE_H
#define VIENGINE_H

#include "qevent.h"
#include "qtextcursor.h"
#include <QObject>

class ViEngine : public QObject
{
    Q_OBJECT
public:
    // Edit Mode
    enum class EditMode {
        CMD     = 0,    // Input Command
        INSERT  ,       // Insert Character
        CMDLINE ,       // Input Command Line(ex-mode)
    };

public:
    explicit ViEngine(QObject *parent = nullptr);
    ~ViEngine();

public:
    EditMode  editMode();                           // 編集モード Getter
    void      setEditMode_low(EditMode value);      // 編集モード Setter
    int       m_repCount = 0;                       // コマンド繰り返し回数

public:
    bool    processKeyPressEvent(QKeyEvent *event); //

public:
    bool    cmdModeKeyPressEvent(QKeyEvent *event); // コマンドモード時キー押下処理
    bool    insModeKeyPressEvent(QKeyEvent *event); // 挿入モード時キー押下処理
    void    processExCommand(const QString &text);  // コマンドライン欄Enterキー押下時処理

private:
    ViEngine::EditMode  m_EditMode;     // 編集モード

signals:
    void    editModeChanged_low(ViEngine::EditMode value);  // 編集モード変更シグナル
    void    moveCursor(QTextCursor::MoveOperation value);   // カーソル移動シグナル

};

#endif // VIENGINE_H
